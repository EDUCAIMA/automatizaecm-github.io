document.addEventListener('DOMContentLoaded', () => {
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');

  if (!hamburger || !mobileMenu) return;

  hamburger.setAttribute('aria-expanded', 'false');

  const toggleMenu = (forceState) => {
    const isOpen = !mobileMenu.hasAttribute('hidden');
    const shouldOpen = typeof forceState === 'boolean' ? forceState : !isOpen;

    if (shouldOpen === isOpen) return;

    if (shouldOpen) {
      mobileMenu.removeAttribute('hidden');
      hamburger.setAttribute('aria-expanded', 'true');
      document.body.classList.add('no-scroll');
    } else {
      mobileMenu.setAttribute('hidden', '');
      hamburger.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('no-scroll');
    }
  };

  // Close the mobile menu when a link is clicked or the viewport grows.
  mobileMenu.addEventListener('click', (event) => {
    if (event.target.matches('a')) {
      toggleMenu(false);
    }
  });

  hamburger.addEventListener('click', () => toggleMenu());

  window.addEventListener('resize', () => {
    if (window.innerWidth > 720) {
      toggleMenu(false);
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      toggleMenu(false);
    }
  });
});
